// AvatarHealthCheck.cs
//
// HOW TO INSTALL:
//   1. Create a folder named "Editor" inside your Assets folder if you don't
//      already have one (e.g. Assets/Editor/).
//   2. Drop this file inside that Editor folder (replace the old version).
//   3. Unity will compile it automatically. Open it via:
//      Tools > Avatar Toolkit > Health Check
//   4. Drag your avatar's root GameObject into the "Target Avatar" field
//      and click "Scan".
//
// v3 changes:
//   - Visual redesign: bigger/clearer type, color-coded severity, category
//     sections that collapse by default when everything in them is fine
//     (so a clean avatar's report is short, not a wall of green text).
//   - Language setting (English / Japanese) via a dropdown in the header.
//     Every generated finding routes through Loc.Tr(...), so switching
//     languages re-labels results you already scanned without re-scanning.
//   - Per-object "Locate" rows (from the previous pass) kept as-is.
//
// WHAT THIS IS:
//   Still an MVP. Thresholds live in HealthCheckConfig below — they're
//   community rules of thumb, not pulled from one official spec, since
//   that spec shifts between SDK versions. Tune freely.
//
//   VRChat SDK types (PhysBone, PhysBoneCollider, VRCAvatarDescriptor) are
//   detected via reflection so this compiles and runs even without the
//   VRChat SDK imported — it just skips those checks and says so.

#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using UnityEditor;
using UnityEditor.Animations;
using UnityEngine;
using UnityEngine.Animations;
using UnityEngine.Profiling;

namespace AvatarToolkit
{
    public static class HealthCheckConfig
    {
        public const int MaterialSlotsWarn = 8;
        public const int MaterialSlotsCritical = 16;

        public const int PolyCountWarn = 32000;
        public const int PolyCountCritical = 70000;

        public const int TextureLongEdgeWarn = 2048;
        public const int TextureLongEdgeCritical = 4096;

        public const long TextureMemoryWarnBytes = 40L * 1024 * 1024;
        public const long TextureMemoryCriticalBytes = 100L * 1024 * 1024;

        public const int PhysBoneCountWarn = 16;
        public const int PhysBoneCountCritical = 32;

        public const int PhysBoneColliderCountWarn = 8;
        public const int PhysBoneColliderCountCritical = 16;

        public const int ParticleMaxParticlesWarn = 500;
        public const int ParticleMaxParticlesCritical = 2000;

        public const int BlendshapeCountWarnUnused = 20;

        public const float TinyScaleThreshold = 0.01f;
        public const float HugeScaleThreshold = 10f;
        public const float NonUniformScaleTolerance = 0.001f;
    }

    public enum AppLanguage { English = 0, Japanese = 1 }

    /// <summary>
    /// All user-facing text lives here as [English, Japanese] pairs, keyed
    /// by a stable id. Findings store the stable category id (e.g.
    /// "scripts"), not the display text, so switching languages relabels
    /// an already-completed scan without needing to re-scan.
    /// </summary>
    public static class Loc
    {
        private const string PrefKey = "AvatarHealthCheck_Language";

        public static AppLanguage Current
        {
            get => (AppLanguage)EditorPrefs.GetInt(PrefKey, (int)AppLanguage.English);
            set => EditorPrefs.SetInt(PrefKey, (int)value);
        }

        private static readonly Dictionary<string, string[]> Map = new Dictionary<string, string[]>
        {
            ["window_title"] = new[] { "Avatar Health Check", "アバター ヘルスチェック" },
            ["subtitle"] = new[] { "Drag your avatar's root GameObject in, then Scan.", "アバターのルート GameObject をドラッグして、スキャンを押してください。" },
            ["target_avatar"] = new[] { "Target Avatar", "対象アバター" },
            ["scan"] = new[] { "Scan", "スキャン" },
            ["language"] = new[] { "Language", "言語" },
            ["report_title"] = new[] { "Performance Report", "パフォーマンス レポート" },
            ["summary_good"] = new[] { "{0} fine", "{0} 件 問題なし" },
            ["summary_warn"] = new[] { "{0} worth checking", "{0} 件 要確認" },
            ["summary_crit"] = new[] { "{0} likely to cause problems", "{0} 件 要対応" },
            ["show_objects"] = new[] { "{0} object(s)", "{0} 件のオブジェクト" },
            ["locate"] = new[] { "Locate", "選択" },
            ["remove_missing"] = new[] { "Remove all missing (null) scripts — safe, undoable", "見つからないスクリプトを一括削除（安全・元に戻せます）" },
            ["no_findings_yet"] = new[] { "Run a scan to see results.", "スキャンを実行すると結果が表示されます。" },
            ["section_critical"] = new[] { "Likely to cause problems", "問題を起こす可能性が高い" },
            ["section_warning"] = new[] { "Worth checking", "確認をおすすめします" },
            ["section_fine"] = new[] { "Looks fine", "問題なし" },
            ["advice_heading"] = new[] { "💡 What should I do?", "💡 どうすればいい?" },

            ["scripts_found_advice"] = new[] {
                "This can break your avatar's upload or make parts of it silently stop working. Worth fixing now — the removal button below is safe and undoable.",
                "見つからないスクリプトはアップロードの失敗や、気づかないうちに一部の機能が動かなくなる原因になります。今のうちに直しておくのがおすすめです。下の削除ボタンは安全で、元に戻すこともできます。" },

            ["materials_slots_advice"] = new[] {
                "This alone won't stop your avatar from uploading — more materials just means more work for the GPU. If you're targeting Quest, VRChat's performance ranking cares about this a lot. If you're PC-only among friends, try the avatar out first; if it feels smooth, it's fine to leave as is.",
                "これだけでアップロードが止まることはありません。マテリアルが多いとGPUの描画負荷が増えるだけです。Quest向けを目指しているなら、VRChatのパフォーマンスランクに大きく影響します。PC専用でフレンドと遊ぶだけなら、まず実際に試してみて、動作が重く感じなければそのままで問題ありません。" },

            ["materials_dupe_advice"] = new[] {
                "This is just a cleanup tip, not a functional problem — nothing will break if you leave it. Consolidating makes the avatar lighter, but it's optional.",
                "これは整理整頓の提案であり、機能的な問題ではありません。放置しても何も壊れません。統合するとアバターが軽くなりますが、必須ではありません。" },

            ["polys_advice"] = new[] {
                "High poly counts mainly affect your Quest performance rank; PC has much more headroom. If you're not chasing a specific rank and the avatar looks and moves fine when you test it, this is safe to leave alone.",
                "ポリゴン数が多いと主にQuestのパフォーマンスランクに影響します。PCでは余裕があります。特定のランクを狙っていなくて、実際に試して見た目や動きに問題がなければ、そのままで大丈夫です。" },

            ["tex_mem_advice"] = new[] {
                "Texture memory mostly affects load times for people around you and your Quest performance rank. If you're PC-only and nobody's mentioned slow loading, this usually isn't worth chasing.",
                "テクスチャメモリは主に周囲の人の読み込み時間とQuestのパフォーマンスランクに影響します。PC専用で、読み込みが遅いと言われたことがなければ、あまり気にしなくて大丈夫です。" },

            ["tex_big_advice"] = new[] {
                "Same idea as texture memory — rarely noticeable at normal viewing distance. Worth downscaling if you're chasing Quest performance rank or a smaller upload size, otherwise low priority.",
                "テクスチャメモリと同じ考え方です。通常の距離ではほとんど気になりません。Questのパフォーマンスランクやアップロードサイズを気にするなら縮小の価値がありますが、そうでなければ優先度は低いです。" },

            ["hier_disabled_advice"] = new[] {
                "Purely a housekeeping note — disabled renderers don't draw, so nothing looks wrong. Only worth removing if you want a smaller, cleaner file.",
                "整理整頓のためのお知らせです。無効なレンダラーは描画されないため、見た目には問題ありません。ファイルを軽くしたい場合のみ削除を検討してください。" },

            ["hier_scalehidden_advice"] = new[] {
                "Not a visible bug, but a zero-scaled object is technically still active and can quietly add cost. If you're not chasing performance rank, it's fine to leave — just know it's there next time you're cleaning up.",
                "見た目には問題ありませんが、ゼロスケールのオブジェクトは技術的には有効なままで、気づかないコストになることがあります。パフォーマンスランクを気にしないなら放置してもかまいませんが、次回整理する際には覚えておいてください。" },

            ["anim_broken_advice"] = new[] {
                "This can't cause a crash or block your upload — a broken binding just quietly does nothing. Only worth fixing if you notice a specific animation not behaving the way you expect.",
                "これがクラッシュやアップロード失敗の原因になることはありません。壊れたバインディングは単に何も起こらないだけです。特定のアニメーションが期待通りに動かないと感じた場合のみ、修正を検討してください。" },

            ["constraints_broken_advice"] = new[] {
                "Same idea as a broken animation — it just won't move things the way it's supposed to. Test the specific effect in-game; if nothing looks wrong, it may be a safe-to-delete leftover from an old setup.",
                "上のアニメーションの問題と同じで、対象が意図通りに動かないだけです。実際にゲーム内で確認してみて、見た目に問題がなければ、古い設定の削除しても安全な残骸かもしれません。" },

            ["physbone_count_advice"] = new[] {
                "This affects Quest performance rank and adds some CPU cost on PC too. If the avatar feels smooth when you test it in a full room, you're fine as is. Only worth trimming if you specifically want a higher Quest rank.",
                "これはQuestのパフォーマンスランクに影響し、PCでも多少のCPU負荷が増えます。人が多い場所で試して動作がスムーズなら、そのままで問題ありません。Questで高いランクを狙う場合のみ、数を減らす価値があります。" },

            ["physbone_collider_advice"] = new[] {
                "Same idea as PhysBone count — affects Quest rank and adds a little CPU cost. Test in a full room; if it feels fine, leave it. Only trim these down if you specifically want a higher Quest rank.",
                "PhysBoneの数と同じ考え方です。Questのランクに影響し、多少のCPU負荷も増えます。人が多い場所で試して問題なければそのままで構いません。Questで高いランクを狙う場合のみ数を減らす価値があります。" },

            ["legacy_found_advice"] = new[] {
                "This one actually matters: Dynamic Bone is not supported by VRChat's current uploader at all. You'll need to convert these to PhysBone components — there's no way to upload with Dynamic Bone still attached.",
                "これは実際に対応が必要です。Dynamic BoneはVRChatの現在のアップローダーではサポートされていません。PhysBoneコンポーネントへの変換が必須で、Dynamic Boneが付いたままではアップロードできません。" },

            ["particles_expensive_advice"] = new[] {
                "Cost depends a lot on how many people are around — something that feels fine alone can lag in a crowded room. If you can, test it in a busy instance; if it's smooth there too, you're okay.",
                "コストは周囲の人数に大きく左右されます。一人の時は問題なくても、混雑した部屋では重く感じることがあります。可能であれば人が多いインスタンスで試してみて、そこでも問題なければ大丈夫です。" },

            ["scale_found_advice"] = new[] {
                "This is more of a 'worth double-checking' flag than a guaranteed problem. If your PhysBones (hair, tails, etc.) move normally and nothing looks stretched, you're fine — just a common culprit to check first if something ever does look off.",
                "これは確実な問題というより「念のため確認しておきたい」項目です。PhysBone（髪や尻尾など）が正常に動いていて見た目が歪んでいなければ問題ありません。何かおかしいと感じたときに真っ先に疑うべき箇所として覚えておくと良いでしょう。" },

            ["blend_found_advice"] = new[] {
                "Not a performance concern — extra blendshapes cost very little at runtime. This is really just a heads-up for your modeler about possible unused sculpt data, not something you need to act on yourself.",
                "パフォーマンス面での心配はいりません。余分なブレンドシェイプの実行時コストはごくわずかです。これはモデラーへの「未使用の可能性があるスカルプトデータ」についてのお知らせであり、あなた自身が対応する必要は基本的にありません。" },

            ["cat_scripts"] = new[] { "Scripts", "スクリプト" },
            ["cat_materials"] = new[] { "Materials", "マテリアル" },
            ["cat_polygons"] = new[] { "Polygons", "ポリゴン" },
            ["cat_textures"] = new[] { "Textures", "テクスチャ" },
            ["cat_hierarchy"] = new[] { "Hierarchy", "ヒエラルキー" },
            ["cat_animations"] = new[] { "Animations", "アニメーション" },
            ["cat_constraints"] = new[] { "Constraints", "コンストレイント" },
            ["cat_physbones"] = new[] { "PhysBones", "PhysBone" },
            ["cat_legacy"] = new[] { "Legacy Components", "レガシー コンポーネント" },
            ["cat_particles"] = new[] { "Particles", "パーティクル" },
            ["cat_audio"] = new[] { "Audio", "オーディオ" },
            ["cat_scaling"] = new[] { "Scaling", "スケーリング" },
            ["cat_blendshapes"] = new[] { "Blendshapes", "ブレンドシェイプ" },

            ["scripts_none"] = new[] { "No missing scripts found", "見つからないスクリプトはありません" },
            ["scripts_found_title"] = new[] { "{0} object(s) have missing scripts", "{0} 件のオブジェクトにスクリプトが見つかりません" },
            ["scripts_found_detail"] = new[] { "Missing scripts commonly cause upload failures or silent breakage. Use the removal button below.", "見つからないスクリプトはアップロード失敗や不具合の原因になります。下のボタンで削除できます。" },

            ["materials_slots_title"] = new[] { "{0} material slots detected", "{0} 個のマテリアル スロットを検出" },
            ["materials_slots_detail_no_reduction"] = new[] { "Recommended: \u2264{0}. Each unique material can add a draw call.", "推奨: {0} 個以下。マテリアルが増えるほど描画コストが増えます。" },
            ["materials_slots_detail_with_reduction"] = new[] { "Recommended: \u2264{0}. Each unique material can add a draw call. Potential reduction if consolidated: ~{1}%", "推奨: {0} 個以下。マテリアルが増えるほど描画コストが増えます。統合した場合の削減率: 約{1}%" },
            ["materials_dupe_title"] = new[] { "{0} material(s) look like duplicates", "{0} 個のマテリアルが重複しているようです" },
            ["materials_dupe_detail"] = new[] { "These match another material's shader and every exposed property exactly, but are separate assets. Often accidental copies from unpacking prefabs — worth consolidating.", "シェーダーと全プロパティが別アセットと完全一致しています。プレハブ展開時の複製ミスであることが多いため、統合を検討してください。" },

            ["polys_title"] = new[] { "{0:N0} triangles detected", "{0:N0} ポリゴンを検出" },
            ["polys_detail"] = new[] { "Rule of thumb: \u2264{0:N0} comfortable, \u2264{1:N0} before it gets heavy. Adjust the config constants for your target platform.", "目安: {0:N0} 以下が快適、{1:N0} 超で重くなります。対象プラットフォームに合わせて設定値を調整してください。" },

            ["tex_mem_title"] = new[] { "~{0:F1} MB texture memory across {1} unique texture(s)", "推定テクスチャメモリ: 約 {0:F1} MB（ユニーク数 {1}）" },
            ["tex_mem_detail"] = new[] { "Warn ~{0} MB, critical ~{1} MB. Rough estimate (uncompressed runtime size) — adjust for your platform.", "警告 約{0}MB、危険 約{1}MB。概算値（非圧縮時）です。プラットフォームに合わせて調整してください。" },
            ["tex_big_title"] = new[] { "{0} texture(s) \u2265{1}px on their long edge", "{0} 個のテクスチャが長辺 {1}px 以上" },
            ["tex_big_detail"] = new[] { "Rarely necessary at typical viewing distance. Consider downscaling.", "通常の距離ではそこまでの解像度は不要な場合が多いです。縮小を検討してください。" },

            ["hier_disabled_title"] = new[] { "{0} renderer(s) disabled but still present", "{0} 個のレンダラーが無効ですが、まだ存在します" },
            ["hier_disabled_detail"] = new[] { "Disabled renderers don't draw but are still uploaded as data. Remove them if unneeded.", "無効なレンダラーは描画されませんが、データとしてアップロードされます。不要なら削除してください。" },
            ["hier_scalehidden_title"] = new[] { "{0} object(s) hidden via near-zero scale instead of being disabled", "{0} 個のオブジェクトが無効化ではなくゼロスケールで隠されています" },
            ["hier_scalehidden_detail"] = new[] { "Still active and still costs performance. Disable the GameObject instead of scaling to zero.", "アクティブなままでコストが発生します。ゼロスケールではなく GameObject を無効化してください。" },
            ["hier_none"] = new[] { "No disabled/hidden-but-present renderers found", "無効化・隠れているレンダラーは見つかりませんでした" },

            ["anim_none"] = new[] { "No broken animation references found", "壊れたアニメーション参照は見つかりませんでした" },
            ["anim_broken_title"] = new[] { "{0} clip(s) reference objects that no longer exist", "{0} 個のクリップが存在しないオブジェクトを参照しています" },
            ["anim_broken_detail"] = new[] { "Usually caused by renaming/moving bones. Broken bindings silently do nothing at runtime.", "ボーンの名前変更や移動が原因です。壊れたバインディングは実行時に無視されます。" },

            ["constraints_none_found"] = new[] { "No Unity constraints found", "Unity コンストレイントは見つかりませんでした" },
            ["constraints_ok"] = new[] { "{0} constraint(s) found, all valid", "{0} 個のコンストレイント、すべて有効" },
            ["constraints_broken_title"] = new[] { "{0} constraint(s) missing a source", "{0} 個のコンストレイントにソースがありません" },
            ["constraints_broken_detail"] = new[] { "Usually means the referenced bone was renamed, deleted, or moved.", "参照先のボーンが名前変更・削除・移動された可能性があります。" },

            ["physbone_sdk_missing"] = new[] { "VRChat SDK not detected — skipped", "VRChat SDK が検出されなかったためスキップしました" },
            ["physbone_count_title"] = new[] { "{0} PhysBone component(s)", "{0} 個の PhysBone コンポーネント" },
            ["physbone_count_detail"] = new[] { "Rule of thumb: \u2264{0}. More PhysBones = more per-frame cost, especially with colliders.", "目安: {0} 以下。多いほどフレームごとの負荷が増えます（コライダー併用時は特に）。" },
            ["physbone_collider_title"] = new[] { "{0} PhysBone Collider(s)", "{0} 個の PhysBone Collider" },
            ["physbone_collider_detail"] = new[] { "Rule of thumb: \u2264{0}. Every collider is checked against every relevant chain.", "目安: {0} 以下。すべてのコライダーが関連チェーンと照合されます。" },

            ["legacy_none"] = new[] { "No legacy Dynamic Bone found", "レガシー Dynamic Bone は見つかりませんでした" },
            ["legacy_found_title"] = new[] { "{0} legacy Dynamic Bone component(s) found", "{0} 個のレガシー Dynamic Bone を検出" },
            ["legacy_found_detail"] = new[] { "Deprecated for VRChat uploads. Convert these to PhysBones.", "VRChat では非推奨です。PhysBone への変換が必要です。" },

            ["particles_none"] = new[] { "No particle systems found", "パーティクルシステムは見つかりませんでした" },
            ["particles_found_title"] = new[] { "{0} particle system(s) found", "{0} 個のパーティクルシステム" },
            ["particles_found_detail"] = new[] { "Informational — cost depends on max particles, collision, and lights modules.", "情報のみ。コストは最大数・コリジョン・ライトモジュールに依存します。" },
            ["particles_expensive_title"] = new[] { "{0} system(s) look potentially expensive", "{0} 個が高負荷の可能性があります" },
            ["particles_expensive_detail"] = new[] { "Flagged for collision enabled and/or a high max particle count.", "コリジョン有効、または最大数が多いことが原因です。" },

            ["audio_title"] = new[] { "{0} AudioSource(s) found", "{0} 個の AudioSource" },
            ["audio_detail"] = new[] { "Informational only.", "情報のみです。" },

            ["scale_none"] = new[] { "No unusual scales found", "異常なスケールは見つかりませんでした" },
            ["scale_found_title"] = new[] { "{0} object(s) with non-uniform or extreme scale", "{0} 個が不均一または極端なスケール" },
            ["scale_found_detail"] = new[] { "Common source of odd PhysBone/collider behavior and animation import quirks.", "PhysBone・コライダーの異常動作やアニメーション不具合の一般的な原因です。" },

            ["blend_none"] = new[] { "No meshes with large unused blendshape counts", "未使用ブレンドシェイプの多いメッシュはありません" },
            ["blend_found_title"] = new[] { "{0} mesh(es) with many unreferenced blendshapes", "{0} 個のメッシュに未参照のブレンドシェイプが多数" },
            ["blend_found_detail"] = new[] { "~{0} total. May be eye-tracking/viseme driven (auto-excluded where possible) or leftover sculpt targets — check with your modeler.", "合計約{0}個。アイトラッキングやビセーム用の可能性（可能な範囲で自動除外済み）もありますが、モデラーに確認をおすすめします。" },
        };

        public static string Tr(string key, params object[] args)
        {
            if (!Map.TryGetValue(key, out var arr)) return key;
            int idx = (int)Current;
            string template = idx < arr.Length ? arr[idx] : arr[0];
            return args.Length > 0 ? string.Format(template, args) : template;
        }
    }

    public enum Severity { Good, Info, Warning, Critical }

    public class Finding
    {
        public Severity Severity;
        public string CategoryId;   // stable id, e.g. "scripts" — localized at draw time
        public string TitleKey;
        public object[] TitleArgs;
        public string DetailKey;    // null/empty = no detail line
        public object[] DetailArgs;
        public UnityEngine.Object[] Culprits;
        public string AdviceKey;    // null/empty = no "what should I do" line
        public object[] AdviceArgs;

        public Finding(Severity sev, string categoryId, string titleKey, object[] titleArgs,
            string detailKey = null, object[] detailArgs = null, UnityEngine.Object[] culprits = null,
            string adviceKey = null, object[] adviceArgs = null)
        {
            Severity = sev;
            CategoryId = categoryId;
            TitleKey = titleKey;
            TitleArgs = titleArgs ?? Array.Empty<object>();
            DetailKey = detailKey;
            DetailArgs = detailArgs ?? Array.Empty<object>();
            Culprits = culprits ?? Array.Empty<UnityEngine.Object>();
            AdviceKey = adviceKey;
            AdviceArgs = adviceArgs ?? Array.Empty<object>();
        }

        // Rendered fresh every draw call using whatever language is
        // currently selected — this is what makes switching languages
        // apply retroactively to an already-completed scan.
        public string Title => Loc.Tr(TitleKey, TitleArgs);
        public string Advice => string.IsNullOrEmpty(AdviceKey) ? "" : Loc.Tr(AdviceKey, AdviceArgs);
        public string Detail => string.IsNullOrEmpty(DetailKey) ? "" : Loc.Tr(DetailKey, DetailArgs);
    }

    public class AvatarHealthCheckWindow : EditorWindow
    {
        private GameObject _target;
        private Vector2 _scroll;
        private List<Finding> _findings = new List<Finding>();
        private bool _hasScanned = false;
        private readonly Dictionary<string, bool> _itemFoldouts = new Dictionary<string, bool>();
        private readonly Dictionary<string, bool> _categoryFoldouts = new Dictionary<string, bool>();

        private static readonly Color GoodColor = new Color(0.35f, 0.72f, 0.36f);
        private static readonly Color WarnColor = new Color(0.85f, 0.68f, 0.20f);
        private static readonly Color CritColor = new Color(0.82f, 0.32f, 0.30f);
        private static readonly Color InfoColor = new Color(0.55f, 0.55f, 0.58f);

        private GUIStyle _titleStyle;
        private GUIStyle _subtitleStyle;
        private GUIStyle _categoryHeaderStyle;
        private GUIStyle _findingTitleStyle;
        private GUIStyle _findingDetailStyle;
        private GUIStyle _adviceHeadingStyle;
        private GUIStyle _adviceTextStyle;
        private GUIStyle _statNumberStyle;
        private GUIStyle _statLabelStyle;

        [MenuItem("TeeTools/Avatar Health")]
        public static void ShowWindow()
        {
            var win = GetWindow<AvatarHealthCheckWindow>("Avatar Health Check");
            win.minSize = new Vector2(440, 520);
        }

        private void InitStyles()
        {
            // Deliberately NOT cached behind a "built once" flag: if the
            // very first call after a script recompile happens before
            // Unity's EditorStyles are fully ready, a cached-forever null
            // style here would throw a NullReferenceException on every
            // single frame from then on until the window is closed and
            // reopened. Rebuilding each call costs nothing noticeable for
            // a window this size and removes that entire failure mode.
            _titleStyle = new GUIStyle(EditorStyles.boldLabel) { fontSize = 16, margin = new RectOffset(4, 4, 6, 2) };
            _subtitleStyle = new GUIStyle(EditorStyles.miniLabel) { wordWrap = true, fontStyle = FontStyle.Italic, margin = new RectOffset(4, 4, 0, 8) };
            _categoryHeaderStyle = new GUIStyle(EditorStyles.foldout) { fontSize = 13, fontStyle = FontStyle.Bold, margin = new RectOffset(2, 2, 6, 2) };
            _findingTitleStyle = new GUIStyle(EditorStyles.label) { fontSize = 12, fontStyle = FontStyle.Bold, wordWrap = true };
            _findingDetailStyle = new GUIStyle(EditorStyles.label) { fontSize = 11, wordWrap = true, richText = false };
            _findingDetailStyle.normal.textColor = new Color(0.75f, 0.75f, 0.75f);
            _adviceHeadingStyle = new GUIStyle(EditorStyles.miniBoldLabel) { fontSize = 11 };
            _adviceHeadingStyle.normal.textColor = new Color(0.55f, 0.78f, 0.95f);
            _adviceTextStyle = new GUIStyle(EditorStyles.label) { fontSize = 11, wordWrap = true, fontStyle = FontStyle.Italic };
            _adviceTextStyle.normal.textColor = new Color(0.85f, 0.85f, 0.85f);
            _statNumberStyle = new GUIStyle(EditorStyles.boldLabel) { fontSize = 20, alignment = TextAnchor.MiddleCenter };
            _statLabelStyle = new GUIStyle(EditorStyles.miniLabel) { alignment = TextAnchor.MiddleCenter, wordWrap = true };
        }

        private void OnGUI()
        {
            InitStyles();

            EditorGUILayout.BeginHorizontal();
            GUILayout.Label(Loc.Tr("window_title"), _titleStyle);
            GUILayout.FlexibleSpace();
            EditorGUILayout.LabelField(Loc.Tr("language"), GUILayout.Width(60));
            var langNames = new[] { "English", "\u65e5\u672c\u8a9e" };
            int langIdx = (int)Loc.Current;
            int newIdx = EditorGUILayout.Popup(langIdx, langNames, GUILayout.Width(90));
            if (newIdx != langIdx) Loc.Current = (AppLanguage)newIdx;
            EditorGUILayout.EndHorizontal();

            EditorGUILayout.LabelField(Loc.Tr("subtitle"), _subtitleStyle);

            _target = (GameObject)EditorGUILayout.ObjectField(Loc.Tr("target_avatar"), _target, typeof(GameObject), true);

            EditorGUILayout.Space(4);
            using (new EditorGUI.DisabledScope(_target == null))
            {
                var scanStyle = new GUIStyle(GUI.skin.button) { fontSize = 13, fontStyle = FontStyle.Bold };
                if (GUILayout.Button(Loc.Tr("scan"), scanStyle, GUILayout.Height(32)))
                {
                    RunScan(_target);
                    // Scanning changes what the rest of this OnGUI call
                    // would draw (summary + findings appear for the first
                    // time). Rather than let the remainder of this same
                    // Layout/Repaint pass run against suddenly-different
                    // content, bail out cleanly and let the next frame
                    // redraw from a consistent state — this is Unity's own
                    // recommended pattern for exactly this situation.
                    GUIUtility.ExitGUI();
                }
            }

            EditorGUILayout.Space(10);

            if (_hasScanned)
            {
                DrawSummary();
                EditorGUILayout.Space(10);
                DrawFindings();
            }
            else
            {
                EditorGUILayout.HelpBox(Loc.Tr("no_findings_yet"), MessageType.None);
            }
        }

        private void DrawSummary()
        {
            int good = _findings.Count(f => f.Severity == Severity.Good);
            int warn = _findings.Count(f => f.Severity == Severity.Warning);
            int crit = _findings.Count(f => f.Severity == Severity.Critical);

            EditorGUILayout.LabelField(Loc.Tr("report_title"), EditorStyles.boldLabel);
            EditorGUILayout.Space(4);

            // A fixed 3-wide horizontal row has no fallback in IMGUI: if
            // the docked window gets narrower than what all three cards
            // need, the row just overflows past the edge with no
            // scrollbar — the rightmost card silently becomes
            // unreachable, which is exactly what happened when this
            // window got docked into a narrow side panel. Below a width
            // threshold, stack the cards vertically instead so every
            // number stays visible and reachable regardless of dock width.
            bool narrow = position.width < 360f;

            if (narrow)
            {
                DrawStatCard(good, Loc.Tr("summary_good"), GoodColor);
                DrawStatCard(warn, Loc.Tr("summary_warn"), WarnColor);
                DrawStatCard(crit, Loc.Tr("summary_crit"), CritColor);
            }
            else
            {
                EditorGUILayout.BeginHorizontal();
                DrawStatCard(good, Loc.Tr("summary_good"), GoodColor);
                DrawStatCard(warn, Loc.Tr("summary_warn"), WarnColor);
                DrawStatCard(crit, Loc.Tr("summary_crit"), CritColor);
                EditorGUILayout.EndHorizontal();
            }
        }

        private void DrawStatCard(int count, string labelTemplate, Color color)
        {
            var prevColor = GUI.backgroundColor;
            GUI.backgroundColor = new Color(color.r, color.g, color.b, 0.18f);
            EditorGUILayout.BeginVertical("box", GUILayout.Height(56));
            GUI.backgroundColor = prevColor;

            var numStyle = new GUIStyle(_statNumberStyle);
            numStyle.normal.textColor = color;
            EditorGUILayout.LabelField(count.ToString(), numStyle);

            // The count is already shown as the big number above, so the
            // label just needs the descriptive words — format with an
            // empty arg and trim the leftover space where {0} was.
            string displayLabel = string.Format(labelTemplate, "").Replace("  ", " ").Trim();
            EditorGUILayout.LabelField(displayLabel, _statLabelStyle);

            EditorGUILayout.EndVertical();
        }

        private void DrawFindings()
        {
            _scroll = EditorGUILayout.BeginScrollView(_scroll);

            DrawSeverityGroup("section_critical", "\ud83d\udd34", "sec_critical",
                f => f.Severity == Severity.Critical, defaultOpen: true);
            DrawSeverityGroup("section_warning", "\ud83d\udfe1", "sec_warning",
                f => f.Severity == Severity.Warning, defaultOpen: true);
            DrawSeverityGroup("section_fine", "\ud83d\udfe2", "sec_fine",
                f => f.Severity == Severity.Good || f.Severity == Severity.Info, defaultOpen: false);

            EditorGUILayout.Space(10);
            var removeStyle = new GUIStyle(GUI.skin.button) { wordWrap = true };
            if (GUILayout.Button(Loc.Tr("remove_missing"), removeStyle, GUILayout.Height(28)))
            {
                RemoveMissingScripts(_target);
                RunScan(_target);
                // Safe to call even inside the open ScrollView/foldout
                // scopes above — ExitGUI is designed to abort immediately
                // without needing matching End calls first.
                GUIUtility.ExitGUI();
            }

            EditorGUILayout.EndScrollView();
        }

        /// <summary>
        /// Renders one severity-based section (e.g. all Critical findings
        /// across every category, together). This is the primary grouping
        /// now — a first-time user should be able to look at just the
        /// "likely to cause problems" section and know exactly what to
        /// fix, without hunting through per-feature categories where a
        /// single critical issue might sit next to four fine ones.
        /// </summary>
        private void DrawSeverityGroup(string labelKey, string icon, string sectionKey,
            Func<Finding, bool> predicate, bool defaultOpen)
        {
            var items = _findings.Where(predicate).ToList();
            if (items.Count == 0) return;

            if (!_categoryFoldouts.TryGetValue(sectionKey, out bool isOpen))
            {
                isOpen = defaultOpen;
                _categoryFoldouts[sectionKey] = isOpen;
            }

            string header = $"{icon}  {Loc.Tr(labelKey)}  ({items.Count})";
            bool newOpen = EditorGUILayout.Foldout(isOpen, header, true, _categoryHeaderStyle);
            _categoryFoldouts[sectionKey] = newOpen;

            if (!newOpen)
            {
                EditorGUILayout.Space(4);
                return;
            }

            EditorGUI.indentLevel++;
            foreach (var f in items)
            {
                DrawFindingItem(f, f.CategoryId);
            }
            EditorGUI.indentLevel--;
            EditorGUILayout.Space(8);
        }

        private void DrawFindingItem(Finding f, string categoryId)
        {
            Color barColor = f.Severity switch
            {
                Severity.Critical => CritColor,
                Severity.Warning => WarnColor,
                Severity.Good => GoodColor,
                _ => InfoColor
            };

            var prevBg = GUI.backgroundColor;
            GUI.backgroundColor = new Color(barColor.r, barColor.g, barColor.b, 0.10f);
            EditorGUILayout.BeginVertical("box");
            GUI.backgroundColor = prevBg;

            // Category tag so you still know which feature area this is
            // about, even though the primary grouping is now severity.
            var tagStyle = new GUIStyle(EditorStyles.miniLabel) { fontStyle = FontStyle.Bold };
            tagStyle.normal.textColor = new Color(barColor.r, barColor.g, barColor.b, 0.9f);
            EditorGUILayout.LabelField(Loc.Tr("cat_" + categoryId), tagStyle);

            EditorGUILayout.LabelField(f.Title, _findingTitleStyle);
            if (!string.IsNullOrEmpty(f.Detail))
                EditorGUILayout.LabelField(f.Detail, _findingDetailStyle);

            if (!string.IsNullOrEmpty(f.Advice))
            {
                EditorGUILayout.Space(3);
                var prevBg2 = GUI.backgroundColor;
                GUI.backgroundColor = new Color(1f, 1f, 1f, 0.06f);
                EditorGUILayout.BeginVertical("box");
                GUI.backgroundColor = prevBg2;
                EditorGUILayout.LabelField(Loc.Tr("advice_heading"), _adviceHeadingStyle);
                EditorGUILayout.LabelField(f.Advice, _adviceTextStyle);
                EditorGUILayout.EndVertical();
            }

            if (f.Culprits.Length > 0)
            {
                string key = categoryId + "|" + f.TitleKey;
                if (!_itemFoldouts.TryGetValue(key, out bool isOpen)) isOpen = false;
                isOpen = EditorGUILayout.Foldout(isOpen, Loc.Tr("show_objects", f.Culprits.Length), true);
                _itemFoldouts[key] = isOpen;

                if (isOpen)
                {
                    EditorGUI.indentLevel++;
                    foreach (var obj in f.Culprits)
                    {
                        if (obj == null) continue;
                        EditorGUILayout.BeginHorizontal();
                        EditorGUILayout.LabelField(DescribeObject(obj), EditorStyles.miniLabel);
                        if (GUILayout.Button(Loc.Tr("locate"), GUILayout.Width(60)))
                        {
                            LocateObject(obj);
                        }
                        EditorGUILayout.EndHorizontal();
                    }
                    EditorGUI.indentLevel--;
                }
            }

            EditorGUILayout.EndVertical();
            EditorGUILayout.Space(3);
        }

        private static string DescribeObject(UnityEngine.Object obj)
        {
            Transform t = obj switch
            {
                Component c => c.transform,
                GameObject g => g.transform,
                _ => null
            };

            if (t != null)
            {
                var parts = new List<string>();
                for (var cur = t; cur != null; cur = cur.parent) parts.Add(cur.name);
                parts.Reverse();
                string path = string.Join("/", parts);
                return obj is GameObject ? path : $"{path}  ({obj.GetType().Name})";
            }

            string assetPath = AssetDatabase.GetAssetPath(obj);
            return string.IsNullOrEmpty(assetPath) ? obj.name : $"{obj.name} \u2014 {assetPath}";
        }

        private static void LocateObject(UnityEngine.Object obj)
        {
            UnityEngine.Object toSelect = obj is Component comp ? comp.gameObject : obj;
            Selection.activeObject = toSelect;
            EditorGUIUtility.PingObject(toSelect);

            if (toSelect is GameObject && SceneView.lastActiveSceneView != null)
            {
                SceneView.lastActiveSceneView.FrameSelected();
            }
        }

        private static void RemoveMissingScripts(GameObject root)
        {
            if (root == null) return;
            int removedTotal = 0;
            foreach (var t in root.GetComponentsInChildren<Transform>(true))
            {
                Undo.RegisterCompleteObjectUndo(t.gameObject, "Remove Missing Scripts");
                int removed = GameObjectUtility.RemoveMonoBehavioursWithMissingScript(t.gameObject);
                removedTotal += removed;
            }
            Debug.Log($"[Avatar Health Check] Removed missing scripts from {removedTotal} component slot(s).");
        }

        // ------------------------------------------------------------------
        // SCAN ENTRY POINT
        // ------------------------------------------------------------------

        private void RunScan(GameObject root)
        {
            _findings = new List<Finding>();
            if (root == null) return;

            CheckMissingScripts(root, _findings);
            CheckMaterialSlotsAndDuplicates(root, _findings);
            CheckPolyCount(root, _findings);
            CheckTextures(root, _findings);
            CheckDisabledRenderersAndHiddenObjects(root, _findings);
            CheckAnimationReferences(root, _findings);
            CheckConstraints(root, _findings);
            CheckPhysBonesAndColliders(root, _findings);
            CheckLegacyDynamicBones(root, _findings);
            CheckParticleSystems(root, _findings);
            CheckAudioSources(root, _findings);
            CheckScaling(root, _findings);
            CheckBlendshapes(root, _findings);

            _hasScanned = true;
        }

        // ------------------------------------------------------------------
        // CHECKS
        // ------------------------------------------------------------------

        private static void CheckMissingScripts(GameObject root, List<Finding> findings)
        {
            var offenders = new List<GameObject>();
            foreach (var t in root.GetComponentsInChildren<Transform>(true))
            {
                int count = GameObjectUtility.GetMonoBehavioursWithMissingScriptCount(t.gameObject);
                if (count > 0) offenders.Add(t.gameObject);
            }

            if (offenders.Count == 0)
            {
                findings.Add(new Finding(Severity.Good, "scripts", "scripts_none", null));
            }
            else
            {
                findings.Add(new Finding(Severity.Critical, "scripts",
                    "scripts_found_title", new object[] { offenders.Count },
                    "scripts_found_detail", null,
                    offenders.Cast<UnityEngine.Object>().ToArray(),
                    adviceKey: "scripts_found_advice"));
            }
        }

        private static void CheckMaterialSlotsAndDuplicates(GameObject root, List<Finding> findings)
        {
            var renderers = root.GetComponentsInChildren<Renderer>(true);
            int totalSlots = renderers.Sum(r => r.sharedMaterials.Length);

            var sev = totalSlots >= HealthCheckConfig.MaterialSlotsCritical ? Severity.Critical
                    : totalSlots >= HealthCheckConfig.MaterialSlotsWarn ? Severity.Warning
                    : Severity.Good;

            if (totalSlots > HealthCheckConfig.MaterialSlotsWarn)
            {
                int pct = Mathf.RoundToInt(100f * (1f - (float)HealthCheckConfig.MaterialSlotsWarn / totalSlots));
                findings.Add(new Finding(sev, "materials",
                    "materials_slots_title", new object[] { totalSlots },
                    "materials_slots_detail_with_reduction", new object[] { HealthCheckConfig.MaterialSlotsWarn, pct },
                    culprits: null, adviceKey: sev != Severity.Good ? "materials_slots_advice" : null));
            }
            else
            {
                findings.Add(new Finding(sev, "materials",
                    "materials_slots_title", new object[] { totalSlots },
                    "materials_slots_detail_no_reduction", new object[] { HealthCheckConfig.MaterialSlotsWarn },
                    culprits: null, adviceKey: sev != Severity.Good ? "materials_slots_advice" : null));
            }

            var allMats = renderers.SelectMany(r => r.sharedMaterials).Where(m => m != null).Distinct().ToList();
            var groups = allMats.GroupBy(m => MaterialSignature(m)).Where(g => g.Count() > 1).ToList();

            if (groups.Count > 0)
            {
                int dupeCount = groups.Sum(g => g.Count() - 1);
                findings.Add(new Finding(Severity.Warning, "materials",
                    "materials_dupe_title", new object[] { dupeCount },
                    "materials_dupe_detail", null,
                    groups.SelectMany(g => g).Cast<UnityEngine.Object>().ToArray(),
                    adviceKey: "materials_dupe_advice"));
            }
        }

        private static string MaterialSignature(Material m)
        {
            // Shader-agnostic: hashes every property the material's OWN
            // shader actually exposes, rather than assuming Standard-shader
            // names like "_MainTex"/"_Color" (which many avatar shaders —
            // Poiyomi, lilToon, URP/Lit — don't use, causing false
            // positives). Texture identity compared by instance ID so two
            // different textures with the same name can't collide.
            var shader = m.shader;
            if (shader == null) return "null-shader";

            var sb = new StringBuilder();
            sb.Append(shader.name);

            int propCount = ShaderUtil.GetPropertyCount(shader);
            for (int i = 0; i < propCount; i++)
            {
                string propName = ShaderUtil.GetPropertyName(shader, i);
                var propType = ShaderUtil.GetPropertyType(shader, i);
                sb.Append('|').Append(propName).Append('=');

                switch (propType)
                {
                    case ShaderUtil.ShaderPropertyType.Color:
                        sb.Append(m.GetColor(propName));
                        break;
                    case ShaderUtil.ShaderPropertyType.Vector:
                        sb.Append(m.GetVector(propName));
                        break;
                    case ShaderUtil.ShaderPropertyType.Float:
                    case ShaderUtil.ShaderPropertyType.Range:
                        sb.Append(m.GetFloat(propName));
                        break;
                    case ShaderUtil.ShaderPropertyType.TexEnv:
                        var tex = m.GetTexture(propName);
                        sb.Append(tex != null ? tex.GetInstanceID().ToString() : "none");
                        break;
                }
            }

            return sb.ToString();
        }

        private static void CheckPolyCount(GameObject root, List<Finding> findings)
        {
            long triCount = 0;

            foreach (var mf in root.GetComponentsInChildren<MeshFilter>(true))
            {
                if (mf.sharedMesh != null) triCount += mf.sharedMesh.triangles.Length / 3;
            }
            foreach (var smr in root.GetComponentsInChildren<SkinnedMeshRenderer>(true))
            {
                if (smr.sharedMesh != null) triCount += smr.sharedMesh.triangles.Length / 3;
            }

            var sev = triCount >= HealthCheckConfig.PolyCountCritical ? Severity.Critical
                    : triCount >= HealthCheckConfig.PolyCountWarn ? Severity.Warning
                    : Severity.Good;

            findings.Add(new Finding(sev, "polygons",
                "polys_title", new object[] { triCount },
                "polys_detail", new object[] { HealthCheckConfig.PolyCountWarn, HealthCheckConfig.PolyCountCritical },
                culprits: null, adviceKey: sev != Severity.Good ? "polys_advice" : null));
        }

        private static void CheckTextures(GameObject root, List<Finding> findings)
        {
            var renderers = root.GetComponentsInChildren<Renderer>(true);
            var mats = renderers.SelectMany(r => r.sharedMaterials).Where(m => m != null).Distinct();

            var textures = new HashSet<Texture>();
            foreach (var m in mats)
            {
                var shader = m.shader;
                if (shader == null) continue;
                int propCount = ShaderUtil.GetPropertyCount(shader);
                for (int i = 0; i < propCount; i++)
                {
                    if (ShaderUtil.GetPropertyType(shader, i) == ShaderUtil.ShaderPropertyType.TexEnv)
                    {
                        string propName = ShaderUtil.GetPropertyName(shader, i);
                        var tex = m.GetTexture(propName);
                        if (tex != null) textures.Add(tex);
                    }
                }
            }

            long totalBytes = 0;
            var oversized = new List<Texture>();
            foreach (var tex in textures)
            {
                long bytes = Profiler.GetRuntimeMemorySizeLong(tex);
                totalBytes += bytes;

                int longEdge = Mathf.Max(tex.width, tex.height);
                if (longEdge >= HealthCheckConfig.TextureLongEdgeWarn)
                    oversized.Add(tex);
            }

            var memSev = totalBytes >= HealthCheckConfig.TextureMemoryCriticalBytes ? Severity.Critical
                       : totalBytes >= HealthCheckConfig.TextureMemoryWarnBytes ? Severity.Warning
                       : Severity.Good;

            findings.Add(new Finding(memSev, "textures",
                "tex_mem_title", new object[] { totalBytes / (1024f * 1024f), textures.Count },
                "tex_mem_detail", new object[] { HealthCheckConfig.TextureMemoryWarnBytes / (1024 * 1024), HealthCheckConfig.TextureMemoryCriticalBytes / (1024 * 1024) },
                culprits: null, adviceKey: memSev != Severity.Good ? "tex_mem_advice" : null));

            if (oversized.Count > 0)
            {
                var critSize = oversized.Where(t => Mathf.Max(t.width, t.height) >= HealthCheckConfig.TextureLongEdgeCritical).ToList();
                var sev = critSize.Count > 0 ? Severity.Critical : Severity.Warning;
                findings.Add(new Finding(sev, "textures",
                    "tex_big_title", new object[] { oversized.Count, HealthCheckConfig.TextureLongEdgeWarn },
                    "tex_big_detail", null,
                    oversized.Cast<UnityEngine.Object>().ToArray(),
                    adviceKey: "tex_big_advice"));
            }
        }

        private static void CheckDisabledRenderersAndHiddenObjects(GameObject root, List<Finding> findings)
        {
            var renderers = root.GetComponentsInChildren<Renderer>(true);
            var disabled = renderers.Where(r => !r.enabled).ToList();
            if (disabled.Count > 0)
            {
                findings.Add(new Finding(Severity.Warning, "hierarchy",
                    "hier_disabled_title", new object[] { disabled.Count },
                    "hier_disabled_detail", null,
                    disabled.Cast<UnityEngine.Object>().ToArray(),
                    adviceKey: "hier_disabled_advice"));
            }

            var scaleHidden = renderers.Where(r =>
                r.enabled && r.gameObject.activeInHierarchy &&
                r.transform.lossyScale.magnitude < HealthCheckConfig.TinyScaleThreshold).ToList();

            if (scaleHidden.Count > 0)
            {
                findings.Add(new Finding(Severity.Warning, "hierarchy",
                    "hier_scalehidden_title", new object[] { scaleHidden.Count },
                    "hier_scalehidden_detail", null,
                    scaleHidden.Cast<UnityEngine.Object>().ToArray(),
                    adviceKey: "hier_scalehidden_advice"));
            }

            if (disabled.Count == 0 && scaleHidden.Count == 0)
            {
                findings.Add(new Finding(Severity.Good, "hierarchy", "hier_none", null));
            }
        }

        private static void CheckAnimationReferences(GameObject root, List<Finding> findings)
        {
            var brokenClips = new List<UnityEngine.Object>();
            var checkedClips = new HashSet<AnimationClip>();

            void ScanController(RuntimeAnimatorController controller)
            {
                if (controller == null) return;
                var clips = controller.animationClips;
                if (clips == null) return;

                foreach (var clip in clips)
                {
                    if (clip == null || checkedClips.Contains(clip)) continue;
                    checkedClips.Add(clip);

                    foreach (var binding in AnimationUtility.GetCurveBindings(clip))
                    {
                        var found = string.IsNullOrEmpty(binding.path) ? root.transform : root.transform.Find(binding.path);
                        if (found == null) brokenClips.Add(clip);
                    }
                    foreach (var binding in AnimationUtility.GetObjectReferenceCurveBindings(clip))
                    {
                        var found = string.IsNullOrEmpty(binding.path) ? root.transform : root.transform.Find(binding.path);
                        if (found == null) brokenClips.Add(clip);
                    }
                }
            }

            foreach (var animator in root.GetComponentsInChildren<Animator>(true))
            {
                ScanController(animator.runtimeAnimatorController);
            }

            var descriptorType = FindTypeByName("VRCAvatarDescriptor");
            if (descriptorType != null)
            {
                var descriptor = root.GetComponentInChildren(descriptorType, true);
                if (descriptor != null)
                {
                    foreach (var fieldName in new[] { "baseAnimationLayers", "specialAnimationLayers" })
                    {
                        var field = descriptorType.GetField(fieldName, BindingFlags.Public | BindingFlags.Instance);
                        if (field == null) continue;
                        var arr = field.GetValue(descriptor) as System.Collections.IEnumerable;
                        if (arr == null) continue;
                        foreach (var layer in arr)
                        {
                            var layerType = layer.GetType();
                            var ctrlField = layerType.GetField("animatorController", BindingFlags.Public | BindingFlags.Instance);
                            var controller = ctrlField?.GetValue(layer) as RuntimeAnimatorController;
                            ScanController(controller);
                        }
                    }
                }
            }

            if (brokenClips.Distinct().Count() == 0)
            {
                findings.Add(new Finding(Severity.Good, "animations", "anim_none", null));
            }
            else
            {
                var distinctClips = brokenClips.Distinct().ToArray();
                findings.Add(new Finding(Severity.Critical, "animations",
                    "anim_broken_title", new object[] { distinctClips.Length },
                    "anim_broken_detail", null,
                    distinctClips,
                    adviceKey: "anim_broken_advice"));
            }
        }

        private static void CheckConstraints(GameObject root, List<Finding> findings)
        {
            var constraints = root.GetComponentsInChildren<IConstraint>(true);
            var broken = new List<UnityEngine.Object>();

            foreach (var c in constraints)
            {
                bool hasSources = c.sourceCount > 0;
                bool anySourceMissing = false;
                for (int i = 0; i < c.sourceCount; i++)
                {
                    var src = c.GetSource(i);
                    if (src.sourceTransform == null) anySourceMissing = true;
                }
                if (!hasSources || anySourceMissing)
                {
                    broken.Add(c as UnityEngine.Object);
                }
            }

            if (constraints.Length == 0)
            {
                findings.Add(new Finding(Severity.Info, "constraints", "constraints_none_found", null));
            }
            else if (broken.Count == 0)
            {
                findings.Add(new Finding(Severity.Good, "constraints", "constraints_ok", new object[] { constraints.Length }));
            }
            else
            {
                findings.Add(new Finding(Severity.Critical, "constraints",
                    "constraints_broken_title", new object[] { broken.Count },
                    "constraints_broken_detail", null,
                    broken.ToArray(),
                    adviceKey: "constraints_broken_advice"));
            }
        }

        private static void CheckPhysBonesAndColliders(GameObject root, List<Finding> findings)
        {
            var pbType = FindTypeByName("VRCPhysBone");
            var pbColliderType = FindTypeByName("VRCPhysBoneCollider");

            if (pbType == null)
            {
                findings.Add(new Finding(Severity.Info, "physbones", "physbone_sdk_missing", null));
                return;
            }

            var pbComponents = root.GetComponentsInChildren(pbType, true);
            var sev = pbComponents.Length >= HealthCheckConfig.PhysBoneCountCritical ? Severity.Critical
                    : pbComponents.Length >= HealthCheckConfig.PhysBoneCountWarn ? Severity.Warning
                    : Severity.Good;

            findings.Add(new Finding(sev, "physbones",
                "physbone_count_title", new object[] { pbComponents.Length },
                "physbone_count_detail", new object[] { HealthCheckConfig.PhysBoneCountWarn },
                pbComponents.Cast<UnityEngine.Object>().ToArray(),
                adviceKey: sev != Severity.Good ? "physbone_count_advice" : null));

            if (pbColliderType != null)
            {
                var colliders = root.GetComponentsInChildren(pbColliderType, true);
                var colSev = colliders.Length >= HealthCheckConfig.PhysBoneColliderCountCritical ? Severity.Critical
                           : colliders.Length >= HealthCheckConfig.PhysBoneColliderCountWarn ? Severity.Warning
                           : Severity.Good;

                findings.Add(new Finding(colSev, "physbones",
                    "physbone_collider_title", new object[] { colliders.Length },
                    "physbone_collider_detail", new object[] { HealthCheckConfig.PhysBoneColliderCountWarn },
                    colliders.Cast<UnityEngine.Object>().ToArray(),
                    adviceKey: colSev != Severity.Good ? "physbone_collider_advice" : null));
            }
        }

        private static void CheckLegacyDynamicBones(GameObject root, List<Finding> findings)
        {
            var dbType = FindTypeByName("DynamicBone");
            if (dbType == null)
            {
                findings.Add(new Finding(Severity.Good, "legacy", "legacy_none", null));
                return;
            }

            var dbComponents = root.GetComponentsInChildren(dbType, true);
            if (dbComponents.Length > 0)
            {
                findings.Add(new Finding(Severity.Critical, "legacy",
                    "legacy_found_title", new object[] { dbComponents.Length },
                    "legacy_found_detail", null,
                    dbComponents.Cast<UnityEngine.Object>().ToArray(),
                    adviceKey: "legacy_found_advice"));
            }
            else
            {
                findings.Add(new Finding(Severity.Good, "legacy", "legacy_none", null));
            }
        }

        private static void CheckParticleSystems(GameObject root, List<Finding> findings)
        {
            var systems = root.GetComponentsInChildren<ParticleSystem>(true);
            if (systems.Length == 0)
            {
                findings.Add(new Finding(Severity.Good, "particles", "particles_none", null));
                return;
            }

            var expensive = new List<UnityEngine.Object>();
            foreach (var ps in systems)
            {
                var main = ps.main;
                bool collisionOn = ps.collision.enabled;
                int maxParticles = main.maxParticles;

                bool flagged = maxParticles >= HealthCheckConfig.ParticleMaxParticlesWarn || collisionOn;
                if (flagged) expensive.Add(ps);
            }

            findings.Add(new Finding(Severity.Info, "particles",
                "particles_found_title", new object[] { systems.Length },
                "particles_found_detail", null));

            if (expensive.Count > 0)
            {
                findings.Add(new Finding(Severity.Warning, "particles",
                    "particles_expensive_title", new object[] { expensive.Count },
                    "particles_expensive_detail", null,
                    expensive.ToArray(),
                    adviceKey: "particles_expensive_advice"));
            }
        }

        private static void CheckAudioSources(GameObject root, List<Finding> findings)
        {
            var sources = root.GetComponentsInChildren<AudioSource>(true);
            findings.Add(new Finding(Severity.Info, "audio",
                "audio_title", new object[] { sources.Length },
                sources.Length > 0 ? "audio_detail" : null, null));
        }

        private static void CheckScaling(GameObject root, List<Finding> findings)
        {
            var offenders = new List<UnityEngine.Object>();
            foreach (var t in root.GetComponentsInChildren<Transform>(true))
            {
                var s = t.localScale;
                bool nonUniform = Mathf.Abs(s.x - s.y) > HealthCheckConfig.NonUniformScaleTolerance ||
                                   Mathf.Abs(s.y - s.z) > HealthCheckConfig.NonUniformScaleTolerance;
                bool extreme = s.magnitude < HealthCheckConfig.TinyScaleThreshold || s.magnitude > HealthCheckConfig.HugeScaleThreshold;

                if (nonUniform || extreme) offenders.Add(t);
            }

            if (offenders.Count == 0)
            {
                findings.Add(new Finding(Severity.Good, "scaling", "scale_none", null));
            }
            else
            {
                findings.Add(new Finding(Severity.Warning, "scaling",
                    "scale_found_title", new object[] { offenders.Count },
                    "scale_found_detail", null,
                    offenders.ToArray(),
                    adviceKey: "scale_found_advice"));
            }
        }

        private static void CheckBlendshapes(GameObject root, List<Finding> findings)
        {
            var smrs = root.GetComponentsInChildren<SkinnedMeshRenderer>(true);
            var usedShapeKeys = new HashSet<string>();

            foreach (var animator in root.GetComponentsInChildren<Animator>(true))
            {
                var controller = animator.runtimeAnimatorController;
                if (controller?.animationClips == null) continue;
                foreach (var clip in controller.animationClips)
                {
                    if (clip == null) continue;
                    foreach (var binding in AnimationUtility.GetCurveBindings(clip))
                    {
                        if (binding.propertyName.StartsWith("blendShape."))
                            usedShapeKeys.Add(binding.propertyName.Substring("blendShape.".Length));
                    }
                }
            }

            int totalUnused = 0;
            var flaggedMeshes = new List<UnityEngine.Object>();

            foreach (var smr in smrs)
            {
                var mesh = smr.sharedMesh;
                if (mesh == null) continue;
                int count = mesh.blendShapeCount;
                if (count == 0) continue;

                int unusedOnThisMesh = 0;
                for (int i = 0; i < count; i++)
                {
                    string name = mesh.GetBlendShapeName(i);
                    bool likelyRuntimeDriven = name.StartsWith("vrc.", StringComparison.OrdinalIgnoreCase)
                                             || name.ToLower().Contains("vrcft")
                                             || name.ToLower().Contains("eye");
                    if (!usedShapeKeys.Contains(name) && !likelyRuntimeDriven)
                        unusedOnThisMesh++;
                }

                if (unusedOnThisMesh >= HealthCheckConfig.BlendshapeCountWarnUnused)
                {
                    totalUnused += unusedOnThisMesh;
                    flaggedMeshes.Add(smr);
                }
            }

            if (flaggedMeshes.Count == 0)
            {
                findings.Add(new Finding(Severity.Good, "blendshapes", "blend_none", null));
            }
            else
            {
                findings.Add(new Finding(Severity.Warning, "blendshapes",
                    "blend_found_title", new object[] { flaggedMeshes.Count },
                    "blend_found_detail", new object[] { totalUnused },
                    flaggedMeshes.ToArray(),
                    adviceKey: "blend_found_advice"));
            }
        }

        // ------------------------------------------------------------------
        // REFLECTION HELPER
        // ------------------------------------------------------------------

        private static Type FindTypeByName(string typeName)
        {
            foreach (var asm in AppDomain.CurrentDomain.GetAssemblies())
            {
                Type[] types;
                try { types = asm.GetTypes(); }
                catch (ReflectionTypeLoadException e) { types = e.Types.Where(t => t != null).ToArray(); }

                var match = types.FirstOrDefault(t => t.Name == typeName && typeof(Component).IsAssignableFrom(t));
                if (match != null) return match;
            }
            return null;
        }
    }
}
#endif
